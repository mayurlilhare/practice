package com.sunbeam;

public class Deque {
	static class Node {
		private int data;
		private Node next;
		private Node prev;
		public Node() {
			this.data = 0;
			this.next = null;
			this.prev = null;
		}
		public Node(int data) {
			this.data = data;
			this.next = null;
			this.prev = null;
		}
	}
	
	private Node head;
	private Node tail;
	public Deque() {
		head = null;
		tail = null;
	}
	public boolean isEmpty() {
		return head == null;
	}
	public void addFirst(int val) {
		Node newnode = new Node(val);
		if(isEmpty()) {
			head = newnode;
			tail = newnode;
		}
		else {
			newnode.next = head;
			head.prev = newnode;
			head = newnode;
		}
	}
	public void addLast(int val) {
		Node newnode = new Node(val);
		if(isEmpty()) {
			head = newnode;
			tail = newnode;
		}
		else {
			tail.next = newnode;
			newnode.prev = tail;
			tail = newnode;
		}		
	}
	public int delFirst() {
		if(isEmpty())
			return 0;
		int val = head.data;
		if(head.next == null) {
			head = null;
			tail = null;
		}
		else {
			head = head.next;
			head.prev = null;
		}
		return val;
	}
	public int delLast() {
		if(isEmpty())
			return 0;
		int val = tail.data;
		if(head.next == null) {
			head = null;
			tail = null;
		}
		else {
			tail = tail.prev;
			tail.next = null;
		}
		return val;
	}
}
