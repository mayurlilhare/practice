/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class Demo05_01Main {
	public static void main(String[] args) {
		Deque dq = new Deque();
		dq.addFirst(10);	// 10
		dq.addFirst(20);	// 20, 10
		dq.addLast(30);		// 20, 10, 30
		dq.addLast(40);		// 20, 10, 30, 40
		int val;
		val = dq.delFirst(); // 10, 30, 40
		System.out.println("delFirst() : " + val); // 20
		val = dq.delFirst(); // 30, 40
		System.out.println("delFirst() : " + val); // 10
		val = dq.delLast(); // 30
		System.out.println("delLast() : " + val); // 40
		val = dq.delLast(); // 
		System.out.println("delLast() : " + val); // 30
		System.out.println("isEmpty() : " + dq.isEmpty()); // true
	}
}
