package com.sunbeam;

public class Demo05_02Main {

	public static void main(String[] args) {
		SinglyLinearList list = new SinglyLinearList();
		list.addLast(30);
		list.addLast(10);
		list.addLast(40);
		list.addLast(20);
		list.display();
		list.selectionSort();
		list.display();
		list.reverse();
		list.display();
		list.delAll();
		list.addLast(11);
		list.addLast(22);
		list.addLast(33);
		list.addLast(44);
		list.display();
		list.revDisplay();
	}

}
