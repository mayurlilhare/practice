/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class SinglyLinearList {
	static class Node {
		private int data;
		private Node next;
		public Node() {
			this.data = 0;
			this.next = null;
		}
		public Node(int data) {
			this.data = data;
			this.next = null;
		}
		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
		public int getData() {
			return data;
		}
	}
	
	private Node head;
	public SinglyLinearList() {
		head = null;
	}
	public void display() {
		System.out.print("List: ");
		Node trav = head;
		while(trav != null) {
			System.out.print(trav.data + " -> ");
			trav = trav.next;
		}
		System.out.println();
	}
	public boolean isEmpty() {
		return head == null;
	}
	public void addLast(int val) {
		Node newnode = new Node(val);
		if(isEmpty())
			head = newnode;
		else {
			Node trav = head;
			while(trav.next != null)
				trav = trav.next;
			trav.next = newnode;
		}
	}
	
	public void selectionSort() {
		for(Node i=head; i!=null; i=i.next) {
			for(Node j=i.next; j!=null; j=j.next) {
				if(i.data > j.data) {
					int temp = i.data;
					i.data = j.data;
					j.data = temp;
				}
			}
		}
	}
	
	public void reverse() {
		Node oldhead = head;
		head = null;
		while(oldhead != null) {
			Node temp = oldhead;
			oldhead = oldhead.next;
			temp.next = head;
			head = temp;
		}
	}
	// time: O(n)
	public void revDisplay(Node cur) {
		if(cur == null)
			return;
		revDisplay(cur.next);
		System.out.print(cur.data + ", ");
	}
	public void revDisplay() {
		System.out.print("Rev List: ");
		revDisplay(head);
		System.out.println();
	}
	public void delAll() {
		head = null;
	}
}



