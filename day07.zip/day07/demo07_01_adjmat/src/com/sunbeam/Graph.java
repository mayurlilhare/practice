/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class Graph {
	private boolean [][]mat;
	private int vertCount, edgeCount;
	public Graph(int vCount) {
		vertCount = vCount;
		mat = new boolean[vertCount][vertCount];
	}
	public void accept(Scanner sc) {
		System.out.print("Enter number of edges: ");
		edgeCount = sc.nextInt();
		for(int i=0; i<edgeCount; i++) {
			System.out.print("Enter edge (src dest): ");
			int src = sc.nextInt();
			int dest = sc.nextInt();
			mat[src][dest] = true;
			mat[dest][src] = true; // skip this line if graph is directed.
		}
	}
	public void display() {
		System.out.println("Adjacency Matrix: ");
		for(int s=0; s<vertCount; s++) {
			for(int d=0; d<vertCount; d++) {
				System.out.print((mat[s][d]?1:0) + "\t");
			}
			System.out.println();
		}
	}
	public void dfsTraversal(int start) {
		System.out.print("DFS: ");
		boolean []marked = new boolean[vertCount];
		Stack<Integer> s = new Stack<>();
		marked[start] = true;
		s.push(start);
		while(!s.isEmpty()) {
			int v = s.pop();
			System.out.print(v + ", ");
			for(int d=0; d<vertCount; d++) {
				if(mat[v][d] && !marked[d]) {
					marked[d] = true;
					s.push(d);
				}
			}
		}
		System.out.println();
	}
	public void bfsTraversal(int start) {
		System.out.print("BFS: ");
		boolean []marked = new boolean[vertCount];
		Queue<Integer> q = new LinkedList<>();
		marked[start] = true;
		q.offer(start);
		while(!q.isEmpty()) {
			int v = q.poll();
			System.out.print(v + ", ");
			for(int d=0; d<vertCount; d++) {
				if(mat[v][d] && !marked[d]) {
					marked[d] = true;
					q.offer(d);
				}
			}
		}
		System.out.println();
	}
	public boolean isConncted() {
		int start = 0, vCount = 0;
		boolean []marked = new boolean[vertCount];
		Stack<Integer> s = new Stack<>();
		marked[start] = true;
		s.push(start);
		vCount++;
		while(!s.isEmpty()) {
			int v = s.pop();
			for(int d=0; d<vertCount; d++) {
				if(mat[v][d] && !marked[d]) {
					marked[d] = true;
					s.push(d);
					vCount++;
				}
			}
		}
		return vCount == this.vertCount;
	}
	public void dfsSpanningTree(int start) {
		System.out.println("DFS Spanning Tree: ");
		boolean []marked = new boolean[vertCount];
		Stack<Integer> s = new Stack<>();
		marked[start] = true;
		s.push(start);
		while(!s.isEmpty()) {
			int v = s.pop();
			for(int d=0; d<vertCount; d++) {
				if(mat[v][d] && !marked[d]) {
					marked[d] = true;
					s.push(d);
					System.out.println(v + " -> " + d);
				}
			}
		}
		System.out.println();
	}
	public void bfsSpanningTree(int start) {
		System.out.println("BFS Spanning Tree: ");
		boolean []marked = new boolean[vertCount];
		Queue<Integer> q = new LinkedList<>();
		marked[start] = true;
		q.offer(start);
		while(!q.isEmpty()) {
			int v = q.poll();
			for(int d=0; d<vertCount; d++) {
				if(mat[v][d] && !marked[d]) {
					marked[d] = true;
					q.offer(d);
					System.out.println(v + " -> " + d);
				}
			}
		}
		System.out.println();
	}
}









