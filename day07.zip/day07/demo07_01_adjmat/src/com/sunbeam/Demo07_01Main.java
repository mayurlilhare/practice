/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import java.util.Scanner;

public class Demo07_01Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of vertices: ");
		int vCount = sc.nextInt();
		Graph g = new Graph(vCount);
		g.accept(sc);
		g.display();
		sc.close();
		g.dfsTraversal(0);
		g.bfsTraversal(0);
		System.out.println("Is Connected: " + g.isConncted());
		g.dfsSpanningTree(0);
		g.bfsSpanningTree(0);
	}

}

/*

6
7
0 1
0 2
0 3
1 2
1 4
3 4
3 5

*/



