/**
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 * Date: 05-Nov-2022 06:52:02
 */
package com.sunbeam;

import java.util.Scanner;

//Adj Matrix for Weighted Non-directed graph
public class AdjMatrixGraph {
	public static final int INF = 999;
	private int vertCount, edgeCount;
	private int adjmat[][];

	public AdjMatrixGraph(int vCount) {
		vertCount = vCount;
		adjmat = new int[vertCount][vertCount];
		for (int s = 0; s < adjmat.length; s++) {
			for (int d = 0; d < adjmat.length; d++)
				adjmat[s][d] = INF;
		}
	}
	
	public void accept(Scanner sc) {
		System.out.print("Enter number of edges: ");
		edgeCount = sc.nextInt();
		for(int i=0; i<edgeCount; i++) {
			System.out.println("Enter edge (src dest weight): ");
			int src = sc.nextInt();
			int dest = sc.nextInt();
			int weight = sc.nextInt();
			adjmat[src][dest] = weight;
			adjmat[dest][src] = weight; // skip this line if graph is directed graph
		}
	}
	
	public void display() {
		for (int s = 0; s < vertCount; s++) {
			for (int d = 0; d < vertCount; d++) {
				System.out.print((adjmat[s][d] != INF ? adjmat[s][d] : "##") + "\t");
			}
			System.out.println();
		}
	}
	public void primsMST(int start) {
		// initialize keys of each vertex to infinity
		int[] keys = new int[vertCount];
		for(int v=0; v<vertCount; v++)
			keys[v] = INF;
		// the parent of each vertex is -1 (initially)
		int[] parent = new int[vertCount];
		for(int v=0; v<vertCount; v++)
			parent[v] = -1;
		// start vertex key set to 0
		keys[start] = 0;
		// all vertices are not in MST (initially)
		boolean[] mst = new boolean[vertCount];
		int mstVertCount = 0;
		
		while(mstVertCount < vertCount) {
			// pick vertex with min key (which is not in MST)
			int u = getMin(keys, mst);
			// add u in mst
			mst[u] = true;
			mstVertCount++;
			// update keys of all neighbors (v), if weight(u,v) < current key of the neighbor. also update the parent of neighbor.
			for (int v = 0; v < vertCount; v++) {
				if(adjmat[u][v] != INF && !mst[v] && adjmat[u][v] < keys[v]) {
					keys[v] = adjmat[u][v];
					parent[v] = u;
				}
			}
		} // repeat for V vertices
	
		int sum = 0;
		for (int v = 0; v < vertCount; v++) {
			int weight, u = parent[v];
			if(u != -1) {
				weight = adjmat[u][v];
				sum = sum + weight;
			}
			System.out.println(u + " -> " + v);
		}
		System.out.println("Weight of MST: " + sum);
	}

	private int getMin(int[] keys, boolean[] mst) {
		int minKey = INF, minVert = -1;
		for (int v = 0; v < vertCount; v++) {
			if(!mst[v] && keys[v] < minKey) {
				minKey = keys[v];
				minVert = v;
			}
		}
		return minVert;
	}
}

















