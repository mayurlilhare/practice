/**
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 * Date: 05-Nov-2022 07:06:02
 */
package com.sunbeam;

import java.util.Scanner;

//Adj Matrix for Weighted Non-directed graph
public class AdjMatrixGraph {
	public static final int INF = 999;
	private int vertCount, edgeCount;
	private int adjmat[][];

	public AdjMatrixGraph(int vCount) {
		vertCount = vCount;
		adjmat = new int[vertCount][vertCount];
		for (int s = 0; s < adjmat.length; s++) {
			for (int d = 0; d < adjmat.length; d++)
				adjmat[s][d] = INF;
		}
	}
	
	public void accept(Scanner sc) {
		System.out.print("Enter number of edges: ");
		edgeCount = sc.nextInt();
		for(int i=0; i<edgeCount; i++) {
			System.out.println("Enter edge (src dest weight): ");
			int src = sc.nextInt();
			int dest = sc.nextInt();
			int weight = sc.nextInt();
			adjmat[src][dest] = weight;
			adjmat[dest][src] = weight; // skip this line if graph is directed graph
		}
	}
	
	public void display() {
		for (int s = 0; s < vertCount; s++) {
			for (int d = 0; d < vertCount; d++) {
				System.out.print((adjmat[s][d] != INF ? adjmat[s][d] : "##") + "\t");
			}
			System.out.println();
		}
	}
	public void dijkstraSPT(int start) {
		// initialize dist of each vertex to infinity
		int[] dist = new int[vertCount];
		for(int v=0; v<vertCount; v++)
			dist[v] = INF;
		// the parent of each vertex is -1 (initially)
		int[] parent = new int[vertCount];
		for(int v=0; v<vertCount; v++)
			parent[v] = -1;
		// start vertex dist set to 0
		dist[start] = 0;
		// all vertices are not in SPT (initially)
		boolean[] spt = new boolean[vertCount];
		int sptVertCount = 0;
		
		while(sptVertCount < vertCount) {
			// pick vertex with min dist (which is not in SPT)
			int u = getMin(dist, spt);
			// add u in spt
			spt[u] = true;
			sptVertCount++;
			// update dist of all neighbors (v), if dist(u) + weight(u,v) < dist(v). also update the parent of neighbor.
			for (int v = 0; v < vertCount; v++) {
				if(adjmat[u][v] != INF && !spt[v] && dist[u] + adjmat[u][v] < dist[v]) {
					dist[v] = dist[u] + adjmat[u][v];
					parent[v] = u;
				}
			}
		} // repeat for V vertices
	
		for (int v = 0; v < vertCount; v++)
			System.out.println("distance from " + start + " to " + v + " is " + dist[v]);
	}

	private int getMin(int[] dist, boolean[] spt) {
		int minKey = INF, minVert = -1;
		for (int v = 0; v < vertCount; v++) {
			if(!spt[v] && dist[v] < minKey) {
				minKey = dist[v];
				minVert = v;
			}
		}
		return minVert;
	}
}

