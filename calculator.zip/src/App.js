import { Button } from 'react-bootstrap';
import './App.css';
import { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faToggleOn, faToggleOff } from '@fortawesome/free-solid-svg-icons';

function App() {
  const [value, setValue] = useState('');
  const [isOn, setIsOn] = useState(false);
  const [black, setBlack] = useState('black');

  const setVal = (e) => {
    if (value === 0) {
      setValue(e.target.value)
    }
    else { setValue(value + e.target.value) }
  }

  const setopr = (e) => {
    if (value === 0) {
      setValue('')
    }
    if (value === '') {
      setValue('')
    }
    else { setValue(value + e.target.value) }
  }
  
  const setZero =(e) => {
    if (value === '') {
      setValue(value)
    }
    else { setValue(value + e.target.value) }
  }

  const setpoint = (e) => {
    setValue(value + e.target.value)
  }

  const toggle = () => {
    if (isOn) {
      setIsOn(false)
      setBlack('black')
    } else {
      setIsOn(true)
      setBlack('white')
    }
  }
  const ondelete = () => {
    if (value === 0) {
      setValue('')
    }
    else {
      setValue(value.slice(0, -1))
    }
  }
  return (
    <div className="App" style={{ background: isOn ? 'white' : 'black'}}>
      <div className="main-div" style={{ border: `1px solid ${black}`, background: isOn ? 'black' : 'white' }}>
        <div className="result-div" style={{ border: `0.1px solid ${black}`, boxShadow: `${black} 0px 0px 2px`, background: isOn ? 'black' : 'white', color: isOn ? 'white' : 'black' }}>{value}</div>
        <FontAwesomeIcon style={{ color: `${black}`, marginLeft: "10px" }} icon={isOn ? faToggleOn : faToggleOff} onClick={toggle} />
        <Button className='calc-btn' onClick={() => { setValue('') }}>Clear</Button>
        <Button className='calc-btn' onClick={ondelete}>Delete</Button>
        <div className="num-div" >
          <div className='num'>
            <input type='button' className='numDiv' id='div1' value='1' onClick={setVal} />
            <input type='button' className='numDiv' id='div2' value='2' onClick={setVal} />
            <input type='button' className='numDiv' id='div3' value='3' onClick={setVal} />
            <input type='button' className='numDiv' id='div4' value='+' onClick={setopr} />

            <input type='button' className='numDiv' id='div5' value='4' onClick={setVal} />
            <input type='button' className='numDiv' id='div6' value='5' onClick={setVal} />
            <input type='button' className='numDiv' id='div7' value='6' onClick={setVal} />
            <input type='button' className='numDiv' id='div8' value='-' onClick={setopr} />

            <input type='button' className='numDiv' id='div9' value='7' onClick={setVal} />
            <input type='button' className='numDiv' id='div10' value='8' onClick={setVal} />
            <input type='button' className='numDiv' id='div11' value='9' onClick={setVal} />
            <input type='button' className='numDiv' id='div16' value='/' onClick={setopr} />

            <input type='button' className='numDiv' id='div14' value='.' onClick={setpoint} />
            <input type='button' className='numDiv' id='div13' value='0' onClick={setZero} />
            <input type='button' className='numDiv' id='div15' value='%' onClick={setopr} />
            <input type='button' className='numDiv' id='div12' value='*' onClick={setopr} />
            
          </div>
          <Button className='result-btn' onClick={() => { setValue(eval(value)) }}>Result</Button>
        </div>
      </div>
    </div>
  );
}

export default App;
