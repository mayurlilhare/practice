/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class Demo04_03Main {

	public static void main(String[] args) {
		DoublyLinearList list = new DoublyLinearList();
		list.addAtPos(10, 0);	// 10
		list.addLast(20);		// 10, 20
		list.addLast(30);		// 10, 20, 30
		list.addLast(40);		// 10, 20, 30, 40
		list.addAtPos(50, 4);	// 10, 20, 30, 50, 40
		list.addAtPos(60, 10);	// 10, 20, 30, 50, 40, 60
		list.displayFwd();
		list.displayRev();
	}

}
