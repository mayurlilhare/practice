/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class DoublyLinearList {
	static class Node {
		private int data;
		private Node next;
		private Node prev;
		public Node() {
			data = 0;
			next = null;
			prev = null;
		}
		public Node(int data) {
			this.data = data;
			next = null;
			prev = null;
		}		
	}
	
	private Node head;
	public DoublyLinearList() {
		head = null;
	}
	
	public boolean isEmpty() {
		return head == null;
	}
	
	public void displayFwd() {
		System.out.print("Fwd List: ");
		Node trav = head;
		while(trav != null) {
			System.out.print(trav.data + " -> ");
			trav = trav.next;
		}
		System.out.println();
	}
	
	public void displayRev() {
		System.out.print("Rev List: ");
		if (!isEmpty()) {
			Node trav = head;
			while (trav.next != null)
				trav = trav.next;
			while (trav != null) {
				System.out.print(trav.data + " -> ");
				trav = trav.prev;
			} 
		}
		System.out.println();
	}
	
	public void addLast(int val) {
		Node newnode = new Node(val);
		if(isEmpty())
			head = newnode;
		else {
			Node trav = head;
			while(trav.next != null)
				trav = trav.next;
			trav.next = newnode;
			newnode.prev = trav;
		}
	}
	
	public void addFirst(int val) {
		Node newnode = new Node(val);
		newnode.next = head;
		if(!isEmpty())
			head.prev = newnode;
		head = newnode;
	}
	
	public void addAtPos(int val, int pos) {
		if(isEmpty() || pos<=1)
			addFirst(val);
		else {
			Node newnode = new Node(val);
			Node trav = head;
			for(int i=1; i<pos-1; i++) {
				if(trav.next == null)
					break;
				trav = trav.next;
			}
			Node temp = trav.next;
			newnode.next = temp;
			newnode.prev = trav;
			trav.next = newnode;
			if(temp != null)
				temp.prev = newnode;
		}
	}
}




