package com.sunbeam;

public class Demo04_01Main {

	public static void main(String[] args) {
		// in stack add/delete is done from same end i.e. head end ---> LIFO behavior
			// addFirst() -- stack push
			// delFirst() -- stack pop
		/*
		LinearList list = new LinearList();
		list.addFirst(10);
		list.addFirst(20);
		list.addFirst(30);
		list.addFirst(40);
		while(!list.isEmpty())
			System.out.println("Popped: " + list.delFirst()); // 40, 30, 20, 10
		*/
		
		// in queue add/delete is done from different ends i.e. tail/head end ---> FIFO behavior
			// addLast() -- queue push
			// delFirst() -- queue pop
		LinearList list = new LinearList();
		list.addLast(10);
		list.addLast(20);
		list.addLast(30);
		list.addLast(40);
		while(!list.isEmpty())
			System.out.println("Popped: " + list.delFirst()); // 40, 30, 20, 10

	}

}
