package com.sunbeam;

public class LinearList {
	static class Node {
		private int data;
		private Node next;
		public Node() {
			data = 0;			next = null;
		}
		public Node(int data) {
			this.data = data;
			next = null;
		}
	}
	
	private Node head;
	private Node tail;
	public LinearList() {
		head = null;
		tail = null;
	}
	public boolean isEmpty() {
		return head == null;
	}
	public void addLast(int val) {
		Node newnode = new Node(val);
		if(isEmpty()) {
			head = newnode;
			tail = newnode;
		}
		else {
			tail.next = newnode;
			tail = newnode;
		}
	}
	public void addFirst(int val) {
		Node newnode = new Node(val);
		if(isEmpty()) {
			head = newnode;
			tail = newnode;
		}
		else {
			newnode.next = head;
			head = newnode;
		}		
	}
	public int delFirst() {
		if(isEmpty())
			return 0;
		int val = head.data;
		if(head.next == null) {
			head = null;
			tail = null;
		}
		else
			head = head.next;
		return val;
	}
}




