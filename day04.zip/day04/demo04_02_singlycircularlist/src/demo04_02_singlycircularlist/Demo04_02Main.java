/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package demo04_02_singlycircularlist;

import com.sunbeam.SinglyCircularList;

public class Demo04_02Main {

	public static void main(String[] args) {
		SinglyCircularList list = new SinglyCircularList();
		list.addLast(10);	// 10
		list.addLast(20);	// 10, 20
		list.addLast(30);	// 10, 20, 30
		list.addLast(40);	// 10, 20, 30, 40
		list.display();
		list.delAtPos(3);	// 10, 20, 40
		list.display();
	}

}
