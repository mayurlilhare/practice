/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class SinglyCircularList {
	static class Node {
		private int data;
		private Node next;
		public Node() {
			data = 0;
			next = null;
		}
		public Node(int data) {
			this.data = data;
			next = null;
		}
	}

	private Node head;
	public SinglyCircularList() {
		head = null;
	}
	public boolean isEmpty() {
		return head == null;
	}
	// O(n)
	public void display() {
		System.out.print("List: ");
		if(!isEmpty()) {
			Node trav = head;
			do {
				System.out.print(trav.data + ", ");
				trav = trav.next;
			}while(trav != head);
		}
		System.out.println();
	}
	// O(n)
	public void addLast(int val) {
		Node newnode = new Node(val);
		if(isEmpty()) {
			head = newnode;
			newnode.next = head; // make newnode circular
		}
		else {
			// traverse till last node
			Node trav = head;
			while(trav.next != head)
				trav = trav.next;
			// add newnode to the next of last node
			trav.next = newnode;
			// newnode's next to head (circular list)
			newnode.next = head;
		}
	}
	// O(n)
	public void addFirst(int val) {
		Node newnode = new Node(val);
		if(isEmpty()) {
			head = newnode;
			newnode.next = head;	// make newnode circular
		}
		else {
			// traverse till last node
			Node trav = head;
			while(trav.next != head)
				trav = trav.next;
			// add newnode to the next of last node
			trav.next = newnode;
			// newnode's next to head (circular list)
			newnode.next = head;
			head = newnode;
		}
	}
	// O(pos)
	public void addAtPos(int val, int pos) {
		if(isEmpty() || pos<=1)
			addFirst(val);
		else {
			Node newnode = new Node(val);
			// traverse till pos-1
			Node trav = head;
			for(int i=1; i<pos-1; i++) {
				if(trav.next == head)	// if reach last node, break (special case: pos beyond last node)
					break;
				trav = trav.next;
			}
			// newnode's next to trav's next (make)
			newnode.next = trav.next;
			// trav's next to newnode (break)
			trav.next = newnode;
		}
	}
	// O(n)
	public void delFirst() {
		if(isEmpty())
			return;
		if(head.next == head) // if single node,
			head = null;		// make head null
		else {
			// traverse till last node
			Node trav = head;
			while(trav.next != head)
				trav = trav.next;
			// head to second node
			head = head.next;
			// last node's next to new head
			trav.next = head;
		}
	}
	// O(1)
	public void delAll() {
		head = null;
	}
	// O(n)
	public void delLast() {
		if(isEmpty())
			return;
		if(head.next == head) // if single node,
			head = null;		// make head null
		else {
			// traverse till last node along with prev pointer
			Node prev = null;
			Node trav = head;
			while(trav.next != head) {
				prev = trav;
				trav = trav.next;
			}
			// prev (second last) node's next to head
			prev.next = head;
			// last node (trav) will be garbage collected
		}
	}
	// O(pos)
	public void delAtPos(int pos) {
		if(isEmpty() || pos < 1)
			return;
		if(pos == 1)
			delFirst();
		else {
			// traverse till given pos along with prev pointer
			Node prev = null;
			Node trav = head;
			for(int i=1; i<pos; i++) {
				if(trav.next == head)	// if reach last node, do nothing (special case: pos beyond last node)
					return;
				prev = trav;
				trav = trav.next;
			}
			// prev's next to trav's next
			prev.next = trav.next;
			// node at trav will be garbage collected
		}
	}
}







