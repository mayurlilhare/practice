const socket = io();

// Get DOM elements in respective js variables
const form = document.getElementById('send-container');
const messageInput = document.getElementById('messageInp');
const messageContainer = document.querySelector('.container');

// Audio that will play on receiving messages
const audio = new Audio('../assets/notificacion.mp3')
const audio1 = new Audio('../assets/notify.mp3')



// function which will append event info to container
const append = (message, position) => {
    const messageElement = document.createElement('div');
    messageElement.innerText = message;
    messageElement.classList.add('message');
    messageElement.classList.add(position);
    messageContainer.append(messageElement);
    if(position =='left'){
        audio.play();
    }
    if(position =='right'){
        audio1.play();
    }
};


// Ask new user for his/her name and let the server know
function getName(){
    let name = prompt("Enter Your name to join");
    if(name == '' || name == null)
        name = getName();
    else
        socket.emit('new-user-joined', name);

    return name;
}
getName();

// If new user joins,receive the event from server
socket.on('user-joined', name => {
    append(`${name} joined the chat`,'left')
});

// If server sends a message receive it
socket.on('recieve', data => {
    append(`${data.name}:${data.message}`,'left')
});

// If user leaves chat send update to container
socket.on('leave', name => {
    append(`${name} left the chat`,'left')
});

// If form gets submitted send it to sever 
form.addEventListener('submit',(e)=>{
    e.preventDefault()
    const message = messageInput.value;
    append(`You : ${message}`,'right')
    socket.emit('send',message)
    messageInput.value = ''
    messageContainer.scrollTo(0, messageContainer.scrollHeight);
})
