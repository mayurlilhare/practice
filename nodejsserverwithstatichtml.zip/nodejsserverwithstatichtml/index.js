const express = require('express');
const http = require('http');
const {Server} = require('socket.io');
const {join} = require('path');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, '/public')));


app.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html");
});
const users = {};
io.on('connection', socket => {

    // If any new user joins, other users get update
    socket.on('new-user-joined', name => {
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);
    });

    // If someone sends a message send to others
    socket.on('send', message => {
        socket.broadcast.emit('recieve', { message: message, name: users[socket.id] });
    });

    // If someone leaves the chat, let others know
    socket.on('disconnect', message => {
        let name = users[socket.id];
        socket.broadcast.emit('leave', name);
        delete users[socket.id];
    });
});

server.listen(3000,()=>{
    console.error("Server started at port: 3000");

})