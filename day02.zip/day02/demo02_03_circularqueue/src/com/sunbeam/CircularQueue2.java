package com.sunbeam;

public class CircularQueue2 {
	private int []arr;
	private int front, rear;
	private int count;
	public CircularQueue2(int size) {
		arr = new int[size];
		rear = -1;
		front = -1;
		count = 0;
	}
	public void push(int val) {
		rear = (rear + 1) % arr.length;
		arr[rear] = val;
		count++;
	}
	public int pop() {
		front = (front + 1) % arr.length;
		int val = arr[front];
		count--;
		return val;
	}
	public int peek() {
		int i = (front + 1) % arr.length;
		return arr[i];
	}
	public boolean isFull() {
		return count == arr.length;
	}
	public boolean isEmpty() {
		return count == 0;
	}
}



