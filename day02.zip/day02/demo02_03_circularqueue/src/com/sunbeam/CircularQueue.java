package com.sunbeam;

public class CircularQueue {
	private int []arr;
	private int front, rear;
	public CircularQueue(int size) {
		arr = new int[size];
		rear = -1;
		front = -1;
	}
	public void push(int val) {
		rear = (rear + 1) % arr.length;
		arr[rear] = val;
	}
	public int pop() {
		front = (front + 1) % arr.length;
		int val = arr[front];
		if(front == rear) {
			rear = -1;
			front = -1;			
		}
		return val;
	}
	public int peek() {
		int i = (front + 1) % arr.length;
		return arr[i];
	}
	public boolean isFull() {
		return (front==-1 && rear==arr.length-1) || (front==rear && rear!=-1);
	}
	public boolean isEmpty() {
		return (front==rear && rear==-1);
	}
}



