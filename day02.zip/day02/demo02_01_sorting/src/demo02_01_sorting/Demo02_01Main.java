/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package demo02_01_sorting;

import java.util.Arrays;

public class Demo02_01Main {
	public static void insertionSort(int[] arr) {
		for(int i=1; i<arr.length; i++) {
			int j, temp = arr[i];
			for(j=i-1; j>=0 && arr[j]>temp; j--)
				arr[j+1] = arr[j];
			arr[j+1] = temp;
		}
	}
	
	public static void main(String[] args) {
		int[] arr = {6, 5, 3, 8, 2, 4};
		System.out.println("Before Sort: " + Arrays.toString(arr));
		insertionSort(arr);
		System.out.println(" After Sort: " + Arrays.toString(arr));
	}

}
