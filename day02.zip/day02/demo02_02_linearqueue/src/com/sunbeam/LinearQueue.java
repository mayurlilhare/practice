package com.sunbeam;

public class LinearQueue {
	private int[] arr;
	private int front, rear;
	
	public LinearQueue(int size) {
		arr = new int[size];
		front = -1;
		rear = -1;
	}
	
	public void push(int val) {
		rear++;
		arr[rear] = val;
	}
	
	public int pop() {
		front++;
		return arr[front];
	}
	
	public int peek() {
		return arr[front+1];
	}
	
	public boolean isFull() {
		return (rear == arr.length-1);
	}

	public boolean isEmpty() {
		return (rear == front);
	}
}



