package com.sunbeam;

import java.util.Scanner;

public class Demo02_02Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LinearQueue q = new LinearQueue(6);
		int val, choice;
		do {
			System.out.print("\n0. Exit\n1. Push\n2. Pop\n3. Peek\nEnter choice: ");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				if(!q.isFull()) {
					System.out.print("Enter value to Push: ");
					val = sc.nextInt();
					q.push(val);
				}
				else
					System.out.println("Queue is Full");
				break;
			case 2:
				if(!q.isEmpty()) {
					val = q.pop();
					System.out.println("Popped: " + val);
				}
				else
					System.out.println("Queue is Empty");
				break;
			case 3:
				if(!q.isEmpty()) {
					val = q.peek();
					System.out.println("Peek: " + val);
				}
				else
					System.out.println("Queue is Empty");
				break;
			}
		} while(choice != 0);
		sc.close();
	}
}
