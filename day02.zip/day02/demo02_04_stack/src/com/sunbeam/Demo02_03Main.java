package com.sunbeam;

import java.util.Scanner;

public class Demo02_03Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack s = new Stack(6);
		int val, choice;
		do {
			System.out.print("\n0. Exit\n1. Push\n2. Pop\n3. Peek\nEnter choice: ");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				if(!s.isFull()) {
					System.out.print("Enter value to Push: ");
					val = sc.nextInt();
					s.push(val);
				}
				else
					System.out.println("Stack is Full");
				break;
			case 2:
				if(!s.isEmpty()) {
					val = s.pop();
					System.out.println("Popped: " + val);
				}
				else
					System.out.println("Stack is Empty");
				break;
			case 3:
				if(!s.isEmpty()) {
					val = s.peek();
					System.out.println("Peek: " + val);
				}
				else
					System.out.println("Stack is Empty");
				break;
			}
		} while(choice != 0);
		sc.close();
	}
}
