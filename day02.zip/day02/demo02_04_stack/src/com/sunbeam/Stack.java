package com.sunbeam;

public class Stack {
	private int[] arr;
	private int top;
	
	public Stack(int size) {
		arr = new int[size];
		top = -1;
	}
	
	public void push(int val) {
		top++;
		arr[top] = val;
	}
	
	public int pop() {
		int val = arr[top];
		top--;
		return val;
	}
	
	public int peek() {
		return arr[top];
	}
	
	public boolean isFull() {
		return top == arr.length-1;
	}
	
	public boolean isEmpty() {
		return top == -1;
	}
}
