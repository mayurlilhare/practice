package com.sunbeam;

import java.util.Scanner;

public class Demo08_04_Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of vertices: ");
		int vCount = sc.nextInt();
		Graph g = new Graph(vCount);
		g.accept(sc);
		g.display();
		
		int start = 0;
		int[] dist = g.bellmanFord(start);
		if(dist == null)
			System.out.println("Graph has -ve weight cycle.");
		else {
			for (int i = 0; i < dist.length; i++)
				System.out.println("Distance of " + i + " from " + start + " = " + dist[i]);
		}
	}
}

/*
5
7
3 4 3
2 4 3
2 3 4
2 1 -2
1 3 -1
0 2 5
0 1 6
*/
