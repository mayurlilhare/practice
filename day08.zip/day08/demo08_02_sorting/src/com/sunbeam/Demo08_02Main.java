package com.sunbeam;

import java.util.Arrays;

public class Demo08_02Main {
	public static void mergeSort(int[] arr, int left, int right) {
		// if partition has single element, return
		if(left == right)
			return;
		// divide array into two equal partitions
		int mid = (left + right) / 2;
		// sort left and right partitions
		mergeSort(arr, left, mid);
		mergeSort(arr, mid+1, right);
		// allocate temp array
		int[] temp = new int[right-left+1];
		// merge two sorted partitions into temp array
		int i=left, j=mid+1, k=0;
		while(i <= mid && j <= right) {
			if(arr[i] < arr[j]) {
				temp[k] = arr[i];
				i++;
				k++;
			}
			else {
				temp[k] = arr[j];
				j++;
				k++;
			}
		}
		while(i <= mid) {
			temp[k] = arr[i];
			i++;
			k++;
		}
		while(j <= right) {
			temp[k] = arr[j];
			j++;
			k++;
		}
		// overwrite temp array back to original array (from left index onwards)
		for(k=0; k<temp.length; k++)
			arr[left+k] = temp[k];
	}
	public static void mergeSort(int[] arr) {
		mergeSort(arr, 0, arr.length-1);
	}
	public static void main(String[] args) {
		int[] arr = { 4, 7, 9, 2, 8, 1, 6, 3, 5 };
		System.out.println(Arrays.toString(arr));
		mergeSort(arr);
		System.out.println(Arrays.toString(arr));
	}

}
