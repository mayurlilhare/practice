/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class Demo08_01Main {
	private static int cnt;
	
    public static int fib(int n) {
        cnt++;
    	if(n == 1 || n == 2)
            return 1;
        int r = fib(n-1) + fib(n-2);
        return r;
    }

    public static int memFib(int n, int[] terms) {
        cnt++;
        if(terms[n] != 0)
        	return terms[n];
    	if(n == 1 || n == 2) {
            terms[n] = 1;
            return terms[n];
    	}
        terms[n] = memFib(n-1, terms) + memFib(n-2, terms);
        return terms[n];
    }
    public static int memFib(int n) {
    	int[] terms = new int[n+1];
    	int res = memFib(n, terms);
    	return res;
    }
    
    public static int dpFib(int n) {
    	int[] terms = new int[n+1];
    	terms[1] = 1;
    	terms[2] = 1;
    	for(int i=3; i<=n; i++) {
        	cnt++;
    		terms[i] = terms[i-1] + terms[i-2];
    	}
    	return terms[n];
    }

    public static void main(String[] args) {
		int term, n = 30;
		cnt=0;
		term = fib(n);
		System.out.println("Recursion: Term = " + term + " with rec calls " + cnt);
		cnt=0;
		term = memFib(n);
		System.out.println("Memoization: Term = " + term + " with rec calls " + cnt);
		cnt=0;
		term = dpFib(n);
		System.out.println("DynProgramming: Term = " + term + " with iterations " + cnt);
	}

}
