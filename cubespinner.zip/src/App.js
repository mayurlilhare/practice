import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './App.css';
import { faCss3, faGit, faHtml5, faJava, faJsSquare, faReact } from '@fortawesome/free-brands-svg-icons';

function App() {
  return (
      <div >
        <div className='stage-cube-cont' style={{background:"black"}}>
        <div className='cubespinner'>
         
           <div className='face1' style={{backgroundColor:"white"}}>
           <FontAwesomeIcon icon={faReact} color='#5ED4F4'/>
          </div>
          <div className='face2' style={{backgroundColor:"white"}}>
          <FontAwesomeIcon icon={faHtml5} color='#F06529'/>
          </div>
          
          <div className='face4' style={{backgroundColor:"white"}}>
          <FontAwesomeIcon icon={faCss3} color='#28A4D9'/>
          </div>
          <div className='face5' style={{backgroundColor:"white"}}>
          <FontAwesomeIcon icon={faJsSquare} color='#EFD81D'/>
          </div>
          
        </div>
      </div>
      </div>
  );
}

export default App;

/////////////////////////////////////////////////////////
 {/* <div className='face1'>
            <FontAwesomeIcon icon={faReact} color='#5ED4F4'/>
          </div>
          <div className='face2'>
            <FontAwesomeIcon icon={faHtml5} color='#F06529'/>
          </div>
          <div className='face3'>
            <FontAwesomeIcon icon={faCss3} color='#28A4D9'/>
          </div>
          <div className='face4'>
            <FontAwesomeIcon icon={faJava} color='#DD0031'/>
          </div>
          <div className='face5'>
            <FontAwesomeIcon icon={faJsSquare} color='#EFD81D'/>
          </div>
          <div className='face6'>
            <FontAwesomeIcon icon={faGit} color='#EC4D28'/>
          </div> */}
