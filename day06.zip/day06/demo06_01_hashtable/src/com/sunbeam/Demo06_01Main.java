/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import java.util.Scanner;

public class Demo06_01Main {

	public static void main(String[] args) {
		HashTable ht = new HashTable();
		ht.put(415110, "Karad Bus Stand");
		ht.put(411052, "Hinjawadi, Pune");
		ht.put(411046, "Katraj, Pune");
		ht.put(411037, "Marketyard, Pune");
		ht.put(411002, "Station, Pune");
		ht.put(400027, "Byculla, Mumbai");
		ht.put(411067, "Aundh, Pune");
		
		ht.put(411002, "Bajirao Road, Pune");
		
		ht.display();

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter pin: ");
		int pin = sc.nextInt();
		String area = ht.get(pin);
		if(area == null)
			System.out.println("Pin not found");
		else
			System.out.println("Area: " + area);
		sc.close();
	}

}
