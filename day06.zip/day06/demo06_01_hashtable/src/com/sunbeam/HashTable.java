/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import java.util.ArrayList;

public class HashTable {
    static class Entry {
        private int key; // pin code
        private String value; // area/city
        public Entry() {
		}
		public Entry(int key, String value) {
			this.key = key;
			this.value = value;
		}
		@Override
		public String toString() {
			return "Entry [key=" + key + ", value=" + value + "]";
		}
    }
    
    static final int SIZE = 10;
    private ArrayList<Entry> []table;
    public HashTable() {
        // initially all buckets (arraylists) are empty
        table = new ArrayList[SIZE];
        for(int i=0; i<SIZE; i++)
            table[i] = new ArrayList<>();
    }
    public int hash(int key) {
        return key % SIZE;
    }
    public void put(int key, String value) {
        // calculate the slot in the table using hash function on key
        int index = hash(key);
        // if entry with same key already present in the bucket, replace its value.
        for(Entry entry:table[index]) {
            if(entry.key == key) {
                entry.value = value;
                return;
            }
        }
        // otherwise, add new entry into the bucket in that slot
        Entry entry = new Entry(key, value);
        table[index].add(entry);
    }
    public String get(int key) {
        // calculate the slot in the table using hash function on key
        int index = hash(key);
        // if entry with same key present in the bucket, return its value.
        for(Entry entry:table[index]) {
            if(entry.key == key)
                return entry.value;
        }
        // otherwise (key not found), return null
        return null;
    }
    public void display() {
    	for(int i=0; i<SIZE; i++) {
    		for(Entry entry:table[i])
    			System.out.println(entry);
    	}
    }
}





