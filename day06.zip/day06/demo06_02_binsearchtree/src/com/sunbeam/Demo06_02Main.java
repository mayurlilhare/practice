/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import com.sunbeam.BinarySearchTree.Node;

public class Demo06_02Main {
	public static void main(String[] args) {
		BinarySearchTree bst = new BinarySearchTree();
		bst.add(50);
		bst.add(30);
		bst.add(90);
		bst.add(10);
		bst.add(40);
		bst.add(70);
		bst.add(100);
		bst.add(20);
		bst.add(60);
		bst.add(80);
		bst.preorder();
		bst.nonrecPreorder();
		bst.inorder();
		bst.nonrecInorder();
		bst.postorder();
		Node temp = bst.find(65);
		if(temp == null)
			System.out.println("Node not found");
		else
			System.out.println("Node Found: " + temp.getData());
		
		Node[] arr = bst.findWithParent(65);
		temp = arr[0];
		Node parent = arr[1];
		if(temp == null)
			System.out.println("Node not found");
		else {
			System.out.println("Node Found: " + temp.getData());
			if(parent != null)
				System.out.println("Node Parent: " + parent.getData());
		}
		
		bst.add(35);
		bst.add(65);
		bst.inorder();
		bst.del(35);
		bst.inorder();
	}
}
