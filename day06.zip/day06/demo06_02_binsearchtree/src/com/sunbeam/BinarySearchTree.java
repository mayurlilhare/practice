/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import java.util.Stack;

public class BinarySearchTree {
	static class Node {
		private int data;
		private Node left, right;
		public Node() {
			data = 0;
			left = null;
			right = null;
		}
		public Node(int data) {
			this.data = data;
			left = null;
			right = null;
		}
		public int getData() {
			return this.data;
		}
	}
	
	private Node root;
	public BinarySearchTree() {
		root = null;
	}
	public void add(int val) {
		Node newnode = new Node(val);
		if(root == null)
			root = newnode;
		else {
			Node trav = root;
			while(true) {
				if(val < trav.data) {
					if(trav.left == null) {
						trav.left = newnode;
						break;
					}
					trav = trav.left;
				}
				else { //val >= trav.data
					if(trav.right == null) {
						trav.right = newnode;
						break;
					}
					trav = trav.right;
				}
			}
		}
	}
	
	public void preorder(Node trav) {
		if(trav == null)
			return;
		System.out.print(trav.data + ", ");
		preorder(trav.left);
		preorder(trav.right);
	}
	public void preorder() {
		System.out.print(" PRE: ");
		preorder(root);
		System.out.println();
	}
	
	public void inorder(Node trav) {
		if(trav == null)
			return;
		inorder(trav.left);
		System.out.print(trav.data + ", ");
		inorder(trav.right);
	}
	public void inorder() {
		System.out.print("  IN: ");
		inorder(root);
		System.out.println();
	}

	public void postorder(Node trav) {
		if(trav == null)
			return;
		postorder(trav.left);
		postorder(trav.right);
		System.out.print(trav.data + ", ");
	}
	public void postorder() {
		System.out.print("POST: ");
		postorder(root);
		System.out.println();
	}
	
	public void nonrecPreorder() {
		System.out.print(" PRE: ");
		Node trav = root;
		Stack<Node> s = new Stack<>();
		while(trav!=null || !s.isEmpty()) {
			while(trav!=null) {
				System.out.print(trav.data + ", ");
				if(trav.right != null)
					s.push(trav.right);
				trav = trav.left;
			}
			if(!s.isEmpty())
				trav = s.pop();
		}
		System.out.println();
	}
	
	public void nonrecInorder() {
		System.out.print("  IN: ");
		Node trav = root;
		Stack<Node> s = new Stack<>();
		while(trav!=null || !s.isEmpty()) {
			while(trav!=null) {
				s.push(trav);
				trav = trav.left;
			}
			if(!s.isEmpty()) {
				trav = s.pop();
				System.out.print(trav.data + ", ");
				trav = trav.right;
			}
		}
		System.out.println();
	}
	
	public Node find(int val) {
		Node trav = root;
		while(trav != null) {
			if(val == trav.data)
				return trav;
			if(val < trav.data)
				trav = trav.left;
			else // (val > trav.data)
				trav = trav.right;
		}
		return null;
	}
	
	public Node[] findWithParent(int val) {
		Node trav = root, parent = null;
		while(trav != null) {
			if(val == trav.data)
				return new Node[]{trav, parent};
			parent = trav;
			if(val < trav.data)
				trav = trav.left;
			else // (val > trav.data)
				trav = trav.right;
		}
		return new Node[]{null, null};
	}
	
	public void del(int val) {
		Node[] arr = findWithParent(val);
		Node temp = arr[0], parent = arr[1];
		if(temp == null)
			return; // node not found
		if(temp.left != null && temp.right != null) {
			parent = temp;
			Node succ = temp.right;
			while(succ.left != null) {
				parent = succ;
				succ = succ.left;
			}
			temp.data = succ.data;
			temp = succ;
		}
		if(temp.left == null) {
			if(temp == root)
				root = temp.right;
			else if(temp == parent.left)
				parent.left = temp.right;
			else
				parent.right = temp.right;
		}
		else if(temp.right == null) {
			if(temp == root)
				root = temp.left;
			else if(temp == parent.left)
				parent.left = temp.left;
			else
				parent.right = temp.left;
		}
	}
}







