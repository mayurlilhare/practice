/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class SinglyLinearList {
	static class Node {
		private int data;
		private Node next;
		public Node() {
			this.data = 0;
			this.next = null;
		}
		public Node(int data) {
			this.data = data;
			this.next = null;
		}
		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
		public int getData() {
			return data;
		}
	}
	
	private Node head;
	public SinglyLinearList() {
		head = null;
	}
	public void display() {
		System.out.print("List: ");
		Node trav = head;
		while(trav != null) {
			System.out.print(trav.data + " -> ");
			trav = trav.next;
		}
		System.out.println();
	}
	public boolean isEmpty() {
		return head == null;
	}
	public void addLast(int val) {
		Node newnode = new Node(val);
		if(isEmpty())
			head = newnode;
		else {
			Node trav = head;
			while(trav.next != null)
				trav = trav.next;
			trav.next = newnode;
		}
	}
	public void addFirst(int val) {
		Node newnode = new Node(val);
		newnode.next = head;
		head = newnode;
	}
	public void addAtPos(int val, int pos) {
		if(isEmpty() || pos<=1)
			addFirst(val);
		else {
			Node newnode = new Node(val);
			Node trav = head;
			for(int i=1; i<pos-1; i++) {
				if(trav.next == null)
					break;
				trav = trav.next;
			}
			newnode.next = trav.next;
			trav.next = newnode;
		}
	}
	
	public void delFirst() {
		if(!isEmpty())
			head = head.next;
	}
	
	public void delAll() {
		head = null;
	}
	
	public void delLast() {
		if(isEmpty())
			return; // do nothing
		if(head.next == null) // single element
			head = null;
		else {
			Node prev = null;
			Node trav = head;
			while(trav.next != null) {
				prev = trav;
				trav = trav.next;
			}
			prev.next = null;
		}
	}
	
	public void delAtPos(int pos) {
		if(isEmpty())
			return;
		if(pos == 1)
			delFirst();
		else {
			Node prev = null;
			Node trav = head;
			for(int i=1; i<pos; i++) {
				if(trav.next == null)
					return;
				prev = trav;
				trav = trav.next;
			}
			prev.next = trav.next;
		}
	}
}





