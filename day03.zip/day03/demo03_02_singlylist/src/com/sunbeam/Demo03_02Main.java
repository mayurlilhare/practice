/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

public class Demo03_02Main {
	public static void main(String[] args) {
		SinglyLinearList list = new SinglyLinearList();
		list.addLast(11);
		list.addLast(22);
		list.addLast(33);
		list.addLast(44);
		list.display(); // 11, 22, 33, 44

		list.delAtPos(3);
		list.display(); // 11, 22, 44
		
		list.delAtPos(7);
		list.display(); // 11, 22, 44
		
		list.delAtPos(1);
		list.display(); // 22, 44
	}
}
