package com.sunbeam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class AssignExprMain {
	public static int pri(String op) {
		switch(op.charAt(0)) {
			case '$':	return 9;
			case '*':	return 5;
			case '/':	return 5;
			case '+':	return 2;
			case '-':	return 2;
		}
		return 0;
	}
	public static double calc(double a, double b, String op) {
		switch(op.charAt(0)) {
			case '$':	return (int)Math.pow(a, b);
			case '*':	return a * b;
			case '/':	return a / b;
			case '+':	return a + b;
			case '-':	return a - b;
		}
		return 0;		
	}
	public static boolean isOperand(String str) {
		if(Character.isAlphabetic(str.charAt(0)))
			return true;
		try {
			Double.parseDouble(str);
			return true;
		}catch (NumberFormatException e) {
			return false;
		}
	}
	public static List<String> infixToPrefix(String infixString) {
		String[] infix = infixString.split(" ");
		List<String> prefix = new ArrayList<>();
		Stack<String> s = new Stack<>();
		//1. Traverse infix expression from right to left.
		for(int i=infix.length-1; i>=0; i--) {
			String symbol = infix[i];
			//2. If current symbol is operand, append it to prefix expression.
			if(isOperand(symbol))
				prefix.add(symbol);
			//6. If closing ) is found, push it on the stack.
			else if(symbol.equals(")"))
				s.push(symbol);
			//7. If opening ( is found, pop operators one by one from stack and append to prefix expression until closing ) is found on stack.
			else if(symbol.equals("(")) {
				while(!s.peek().equals(")"))
					prefix.add(s.pop());
				s.pop(); // Also pop and discard that closing ) from stack.
			}
			else { //3. If current symbol is operator
				//4. If priority of topmost element in stack is greater than priority of the current operator, then pop it and append to prefix expression.
				while(!s.isEmpty() && pri(s.peek()) > pri(symbol))
					prefix.add(s.pop());
				//push it on the stack. *
				s.push(symbol);
			}	
		}
		//5. When all symbols from infix are completed, pop operators one by one from stack and append to prefix expression.
		while(!s.isEmpty())
			prefix.add(s.pop());
		//8. Reverse the prefix string
		Collections.reverse(prefix);
		return prefix;
	}

	public static double solvePrefix(List<String> prefix) {
		Stack<Double> s = new Stack<>();
		//1. Traverse prefix expression from right to left.
		for(int i=prefix.size()-1; i>=0; i--) {
			String symbol = prefix.get(i);
			//2. If current symbol is operand, push it on the stack.
			if(isOperand(symbol))
				s.push(Double.parseDouble(symbol));
			else { 
				//3. If current symbol is operator, pop two operands from the stack, calculate the result and push result back to stack. The first popped will be first operand, and second popped will be the second operand.
				double a = s.pop();
				double b = s.pop();
				double res = calc(a, b, symbol);
				s.push(res);
			}
		}
		//4. When all symbols from prefix are completed, pop the final result from the stack.
		return s.pop();
	}

	public static void main(String[] args) {
		// symbols must be separated by spaces
		String infix = "12 + 3 * ( 5 - 8 / 4 ) + ( 300 - ( 9 + 1 * 7 ) $ 2 )";
		List<String> prefix = infixToPrefix(infix);
		System.out.println(" Prefix: " + prefix);
		double result = solvePrefix(prefix);
		System.out.println(" Prefix Result: " + result);
	}

}
