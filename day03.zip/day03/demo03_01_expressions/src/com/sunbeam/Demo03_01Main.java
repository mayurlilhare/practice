/**
 * Data Structures and Algorithms using Java
 * Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
 **/
package com.sunbeam;

import java.util.Stack;

public class Demo03_01Main {
	public static int pri(char op) {
		switch(op) {
			case '$':	return 9;
			case '*':	return 5;
			case '/':	return 5;
			case '+':	return 2;
			case '-':	return 2;
		}
		return 0;
	}
	public static String infixToPostfix(String infix) {
		StringBuilder postfix = new StringBuilder();
		Stack<Character> s = new Stack<>();
		//1. Traverse infix expression from left to right.
		for(int i=0; i<infix.length(); i++) {
			char symbol = infix.charAt(i);
			//2. If current symbol is operand, append it to postfix expression.
			if(Character.isDigit(symbol) || Character.isAlphabetic(symbol))
				postfix.append(symbol);
			//6. If opening ( is found, push it on the stack.
			else if(symbol == '(')
				s.push(symbol);
			//7. If closing ) is found, pop operators one by one from stack and append to postfix expression until opening ( is found on stack.
			else if(symbol == ')') {
				while(s.peek() != '(')
					postfix.append(s.pop());
				s.pop(); // Also pop and discard that opening ( from stack.
			}
			else { //3. If current symbol is operator
				//4. If priority of topmost element in stack is greater or equal to priority of the current operator, then pop it and append to postfix expression.
				while(!s.isEmpty() && pri(s.peek()) >= pri(symbol))
					postfix.append(s.pop());
				//push it on the stack. *
				s.push(symbol);
			}	
		}
		//5. When all symbols from infix are completed, pop operators one by one from stack and append to postfix expression.
		while(!s.isEmpty())
			postfix.append(s.pop());
		return postfix.toString();
	}
	public static String infixToPrefix(String infix) {
		StringBuilder prefix = new StringBuilder();
		Stack<Character> s = new Stack<>();
		//1. Traverse infix expression from right to left.
		for(int i=infix.length()-1; i>=0; i--) {
			char symbol = infix.charAt(i);
			//2. If current symbol is operand, append it to prefix expression.
			if(Character.isDigit(symbol) || Character.isAlphabetic(symbol))
				prefix.append(symbol);
			//6. If closing ) is found, push it on the stack.
			else if(symbol == ')')
				s.push(symbol);
			//7. If opening ( is found, pop operators one by one from stack and append to prefix expression until closing ) is found on stack.
			else if(symbol == '(') {
				while(s.peek() != ')')
					prefix.append(s.pop());
				s.pop(); // Also pop and discard that closing ) from stack.
			}
			else { //3. If current symbol is operator
				//4. If priority of topmost element in stack is greater than priority of the current operator, then pop it and append to prefix expression.
				while(!s.isEmpty() && pri(s.peek()) > pri(symbol))
					prefix.append(s.pop());
				//push it on the stack. *
				s.push(symbol);
			}	
		}
		//5. When all symbols from infix are completed, pop operators one by one from stack and append to prefix expression.
		while(!s.isEmpty())
			prefix.append(s.pop());
		//8. Reverse the prefix string
		prefix.reverse();
		return prefix.toString();
	}
	
	public static int calc(int a, int b, char op) {
		switch(op) {
			case '$':	return (int)Math.pow(a, b);
			case '*':	return a * b;
			case '/':	return a / b;
			case '+':	return a + b;
			case '-':	return a - b;
		}
		return 0;		
	}
	
	public static int solvePostfix(String postfix) {
		Stack<Integer> s = new Stack<Integer>();
		//1. Traverse postfix expression from left to right.
		for(int i=0; i<postfix.length(); i++) {
			char symbol = postfix.charAt(i);
			//2. If current symbol is operand, push it on the stack.
			if(Character.isDigit(symbol))
				s.push(symbol-'0');
			else { 
				//3. If current symbol is operator, pop two operands from the stack, calculate the result and push result back to stack. The first popped will be second operand, and second popped will be the first operand.
				int b = s.pop();
				int a = s.pop();
				int res = calc(a, b, symbol);
				s.push(res);
			}
		}
		//4. When all symbols from postfix are completed, pop the final result from the stack.
		return s.pop();
	}
	
	public static int solvePrefix(String prefix) {
		Stack<Integer> s = new Stack<Integer>();
		//1. Traverse prefix expression from right to left.
		for(int i=prefix.length()-1; i>=0; i--) {
			char symbol = prefix.charAt(i);
			//2. If current symbol is operand, push it on the stack.
			if(Character.isDigit(symbol))
				s.push(symbol-'0');
			else { 
				//3. If current symbol is operator, pop two operands from the stack, calculate the result and push result back to stack. The first popped will be first operand, and second popped will be the second operand.
				int a = s.pop();
				int b = s.pop();
				int res = calc(a, b, symbol);
				s.push(res);
			}
		}
		//4. When all symbols from prefix are completed, pop the final result from the stack.
		return s.pop();
	}

	public static void main(String[] args) {
		String infix = "5+9-4*(8-6/2)+1$(7-3)";
		//String infix = "A+B*(C-D/E)+(F-(G+H*I)$J)";
		String postfix, prefix;
		postfix = infixToPostfix(infix);
		prefix = infixToPrefix(infix);
		System.out.println("Postfix: " + postfix);
		System.out.println(" Prefix: " + prefix);
		int result = solvePostfix(postfix);
		System.out.println("Postfix Result: " + result);
		result = solvePrefix(prefix);
		System.out.println(" Prefix Result: " + result);
	}

}
