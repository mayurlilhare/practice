package com.sunbeam;

import java.util.Scanner;

public class Demo01_01Main {
	public static int linearSearch(int[] a, int key) {
		for(int i=0; i<a.length; i++) {
			if(key == a[i])
				return i;
		}
		return -1;
	}
	
	public static int binarySearch(int[] arr, int key) {
		int left = 0, right = arr.length-1, mid;
		while(left <= right) {
			mid = (left + right)/2;
			if(key == arr[mid])
				return mid;
			if(key < arr[mid])
				right = mid-1;
			else // key > arr[mid]
				left = mid+1;
		}	
		return -1;
	}
	
	public static int recBinarySearch(int[] arr, int left, int right, int key) {
		if(left > right)
			return -1;
		int index, mid = (left + right) / 2;
		if(key == arr[mid])
			return mid;
		if(key < arr[mid])
			index = recBinarySearch(arr, left, mid-1, key);
		else //(key > arr[mid])
			index = recBinarySearch(arr, mid+1, right, key);
		return index;
	}
	
	public static int recBinarySearch(int[] arr, int key) {
		int index = recBinarySearch(arr, 0, arr.length-1, key);
		return index;
	}
	
	public static void main(String[] args) {
		/*
		int[] arr = { 88, 33, 66, 99, 11, 77, 22, 55, 11 };
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter element to find: ");
		int key = sc.nextInt();
		int index = linearSearch(arr, key);
		if(index == -1) 
			System.out.println("Element not found.");
		else
			System.out.println("Element found at index: " + index);
		sc.close();
		*/
		int[] arr = { 11, 22, 33, 44, 55, 66, 77, 88, 99 };
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter element to find: ");
		int key = sc.nextInt();
		//int index = binarySearch(arr, key);
		int index = recBinarySearch(arr, key);
		if(index == -1) 
			System.out.println("Element not found.");
		else
			System.out.println("Element found at index: " + index);
		sc.close();
	}
}
